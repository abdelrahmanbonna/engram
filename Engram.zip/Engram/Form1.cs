﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Engram
{
    public partial class Main : MetroFramework.Forms.MetroForm
    {
       
        SqlConnection conn = new SqlConnection(Engram.Properties.Settings.Default.DataConnectionString);
        public Main()
        {
            InitializeComponent();
            
            SqlDataAdapter da = new SqlDataAdapter("select Name from grammar", conn);
            conn.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            for (int i = 0; i < dt.Rows.Count; i++) { 
                DataRow row = dt.Rows[i];
                comboBox1.Items.Add(row["Name"].ToString());
            
            }
            conn.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataAdapter Cmd = new SqlDataAdapter("Select * from grammar where Name='"+comboBox1.SelectedItem.ToString()+"'", conn);
            conn.Open();
            DataTable dt = new DataTable();
            Cmd.Fill(dt);
            if (dt.Rows.Count == 1) {
                DataRow row = dt.Rows[0];
                string Decs = row["Desc"].ToString();
                InfoTB.Text = Decs.Replace("\\\\n", Environment.NewLine);
            
            }
            conn.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            info w = new info();
            w.Show();
        }
    }
}
