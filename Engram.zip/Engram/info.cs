﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Engram
{
    public partial class info : MetroFramework.Forms.MetroForm
    {
        public info()
        {
            InitializeComponent();
        }

        public static void GoToSite(string url)
        {
            System.Diagnostics.Process.Start(url);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            GoToSite("https://github.com/abdelrahmanbonna/engram");
        }
    }
}
